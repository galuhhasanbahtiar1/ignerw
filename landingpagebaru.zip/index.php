<!DOCTYPE html>
<html lang="en-US">

<!-- Mirrored from jasafollowersaktif.online/ by HTTrack Website Copier/3.x [XR&CO'2014], Mon, 05 Apr 2021 07:23:23 GMT -->
<!-- Added by HTTrack --><meta http-equiv="content-type" content="text/html;charset=UTF-8" /><!-- /Added by HTTrack -->
<head>
	<meta charset="UTF-8">
	
<meta name='robots' content='max-image-preview:large' />
<title>Instragram Followers - RSPROJECT</title>
<link rel='dns-prefetch' href='http://www.googletagmanager.com/' />
<link rel='dns-prefetch' href='http://s.w.org/' />
<link rel="alternate" type="application/rss+xml" title=" &raquo; Feed" href="feed/index.html" />
<link rel="alternate" type="application/rss+xml" title=" &raquo; Comments Feed" href="comments/feed/index.html" />
		<script>
			window._wpemojiSettings = {"baseUrl":"https:\/\/s.w.org\/images\/core\/emoji\/13.0.1\/72x72\/","ext":".png","svgUrl":"https:\/\/s.w.org\/images\/core\/emoji\/13.0.1\/svg\/","svgExt":".svg","source":{"concatemoji":"https:\/\/jasafollowersaktif.online\/wp-includes\/js\/wp-emoji-release.min.js?ver=5.7"}};
			!function(e,a,t){var n,r,o,i=a.createElement("canvas"),p=i.getContext&&i.getContext("2d");function s(e,t){var a=String.fromCharCode;p.clearRect(0,0,i.width,i.height),p.fillText(a.apply(this,e),0,0);e=i.toDataURL();return p.clearRect(0,0,i.width,i.height),p.fillText(a.apply(this,t),0,0),e===i.toDataURL()}function c(e){var t=a.createElement("script");t.src=e,t.defer=t.type="text/javascript",a.getElementsByTagName("head")[0].appendChild(t)}for(o=Array("flag","emoji"),t.supports={everything:!0,everythingExceptFlag:!0},r=0;r<o.length;r++)t.supports[o[r]]=function(e){if(!p||!p.fillText)return!1;switch(p.textBaseline="top",p.font="600 32px Arial",e){case"flag":return s([127987,65039,8205,9895,65039],[127987,65039,8203,9895,65039])?!1:!s([55356,56826,55356,56819],[55356,56826,8203,55356,56819])&&!s([55356,57332,56128,56423,56128,56418,56128,56421,56128,56430,56128,56423,56128,56447],[55356,57332,8203,56128,56423,8203,56128,56418,8203,56128,56421,8203,56128,56430,8203,56128,56423,8203,56128,56447]);case"emoji":return!s([55357,56424,8205,55356,57212],[55357,56424,8203,55356,57212])}return!1}(o[r]),t.supports.everything=t.supports.everything&&t.supports[o[r]],"flag"!==o[r]&&(t.supports.everythingExceptFlag=t.supports.everythingExceptFlag&&t.supports[o[r]]);t.supports.everythingExceptFlag=t.supports.everythingExceptFlag&&!t.supports.flag,t.DOMReady=!1,t.readyCallback=function(){t.DOMReady=!0},t.supports.everything||(n=function(){t.readyCallback()},a.addEventListener?(a.addEventListener("DOMContentLoaded",n,!1),e.addEventListener("load",n,!1)):(e.attachEvent("onload",n),a.attachEvent("onreadystatechange",function(){"complete"===a.readyState&&t.readyCallback()})),(n=t.source||{}).concatemoji?c(n.concatemoji):n.wpemoji&&n.twemoji&&(c(n.twemoji),c(n.wpemoji)))}(window,document,window._wpemojiSettings);
		</script>
		<style>
img.wp-smiley,
img.emoji {
	display: inline !important;
	border: none !important;
	box-shadow: none !important;
	height: 1em !important;
	width: 1em !important;
	margin: 0 .07em !important;
	vertical-align: -0.1em !important;
	background: none !important;
	padding: 0 !important;
}
</style>
	<link rel='stylesheet' id='wp-block-library-css'  href='wp-includes/css/dist/block-library/style.mine23c.css?ver=5.7' media='all' />
<link rel='stylesheet' id='twentytwenty-style-css'  href='wp-content/themes/twentytwenty/style97e1.css?ver=1.7' media='all' />
<style id='twentytwenty-style-inline-css'>
.color-accent,.color-accent-hover:hover,.color-accent-hover:focus,:root .has-accent-color,.has-drop-cap:not(:focus):first-letter,.wp-block-button.is-style-outline,a { color: #cd2653; }blockquote,.border-color-accent,.border-color-accent-hover:hover,.border-color-accent-hover:focus { border-color: #cd2653; }button,.button,.faux-button,.wp-block-button__link,.wp-block-file .wp-block-file__button,input[type="button"],input[type="reset"],input[type="submit"],.bg-accent,.bg-accent-hover:hover,.bg-accent-hover:focus,:root .has-accent-background-color,.comment-reply-link { background-color: #cd2653; }.fill-children-accent,.fill-children-accent * { fill: #cd2653; }body,.entry-title a,:root .has-primary-color { color: #000000; }:root .has-primary-background-color { background-color: #000000; }cite,figcaption,.wp-caption-text,.post-meta,.entry-content .wp-block-archives li,.entry-content .wp-block-categories li,.entry-content .wp-block-latest-posts li,.wp-block-latest-comments__comment-date,.wp-block-latest-posts__post-date,.wp-block-embed figcaption,.wp-block-image figcaption,.wp-block-pullquote cite,.comment-metadata,.comment-respond .comment-notes,.comment-respond .logged-in-as,.pagination .dots,.entry-content hr:not(.has-background),hr.styled-separator,:root .has-secondary-color { color: #6d6d6d; }:root .has-secondary-background-color { background-color: #6d6d6d; }pre,fieldset,input,textarea,table,table *,hr { border-color: #dcd7ca; }caption,code,code,kbd,samp,.wp-block-table.is-style-stripes tbody tr:nth-child(odd),:root .has-subtle-background-background-color { background-color: #dcd7ca; }.wp-block-table.is-style-stripes { border-bottom-color: #dcd7ca; }.wp-block-latest-posts.is-grid li { border-top-color: #dcd7ca; }:root .has-subtle-background-color { color: #dcd7ca; }body:not(.overlay-header) .primary-menu > li > a,body:not(.overlay-header) .primary-menu > li > .icon,.modal-menu a,.footer-menu a, .footer-widgets a,#site-footer .wp-block-button.is-style-outline,.wp-block-pullquote:before,.singular:not(.overlay-header) .entry-header a,.archive-header a,.header-footer-group .color-accent,.header-footer-group .color-accent-hover:hover { color: #cd2653; }.social-icons a,#site-footer button:not(.toggle),#site-footer .button,#site-footer .faux-button,#site-footer .wp-block-button__link,#site-footer .wp-block-file__button,#site-footer input[type="button"],#site-footer input[type="reset"],#site-footer input[type="submit"] { background-color: #cd2653; }.header-footer-group,body:not(.overlay-header) #site-header .toggle,.menu-modal .toggle { color: #000000; }body:not(.overlay-header) .primary-menu ul { background-color: #000000; }body:not(.overlay-header) .primary-menu > li > ul:after { border-bottom-color: #000000; }body:not(.overlay-header) .primary-menu ul ul:after { border-left-color: #000000; }.site-description,body:not(.overlay-header) .toggle-inner .toggle-text,.widget .post-date,.widget .rss-date,.widget_archive li,.widget_categories li,.widget cite,.widget_pages li,.widget_meta li,.widget_nav_menu li,.powered-by-wordpress,.to-the-top,.singular .entry-header .post-meta,.singular:not(.overlay-header) .entry-header .post-meta a { color: #6d6d6d; }.header-footer-group pre,.header-footer-group fieldset,.header-footer-group input,.header-footer-group textarea,.header-footer-group table,.header-footer-group table *,.footer-nav-widgets-wrapper,#site-footer,.menu-modal nav *,.footer-widgets-outer-wrapper,.footer-top { border-color: #dcd7ca; }.header-footer-group table caption,body:not(.overlay-header) .header-inner .toggle-wrapper::before { background-color: #dcd7ca; }
</style>
<link rel='stylesheet' id='twentytwenty-print-style-css'  href='wp-content/themes/twentytwenty/print97e1.css?ver=1.7' media='print' />
<link rel='stylesheet' id='elementor-icons-css'  href='wp-content/plugins/elementor/assets/lib/eicons/css/elementor-icons.min21f9.css?ver=5.11.0' media='all' />
<link rel='stylesheet' id='elementor-animations-css'  href='wp-content/plugins/elementor/assets/lib/animations/animations.minaeb9.css?ver=3.1.4' media='all' />
<link rel='stylesheet' id='elementor-frontend-css'  href='wp-content/plugins/elementor/assets/css/frontend.minaeb9.css?ver=3.1.4' media='all' />
<link rel='stylesheet' id='elementor-post-13-css'  href='wp-content/uploads/elementor/css/post-133a5d.css?ver=1615435481' media='all' />
<link rel='stylesheet' id='elementor-pro-css'  href='wp-content/plugins/elementor-pro/assets/css/frontend.minb12b.css?ver=3.1.1' media='all' />
<link rel='stylesheet' id='elementor-global-css'  href='wp-content/uploads/elementor/css/global3a5d.css?ver=1615435481' media='all' />
<link rel='stylesheet' id='elementor-post-132-css'  href='wp-content/uploads/elementor/css/post-132515e.css?ver=1617018126' media='all' />
<link rel='stylesheet' id='google-fonts-1-css'  href='https://fonts.googleapis.com/css?family=Roboto%3A100%2C100italic%2C200%2C200italic%2C300%2C300italic%2C400%2C400italic%2C500%2C500italic%2C600%2C600italic%2C700%2C700italic%2C800%2C800italic%2C900%2C900italic%7CRoboto+Slab%3A100%2C100italic%2C200%2C200italic%2C300%2C300italic%2C400%2C400italic%2C500%2C500italic%2C600%2C600italic%2C700%2C700italic%2C800%2C800italic%2C900%2C900italic&amp;ver=5.7' media='all' />
<link rel='stylesheet' id='elementor-icons-shared-0-css'  href='wp-content/plugins/elementor/assets/lib/font-awesome/css/fontawesome.min9e0b.css?ver=5.15.1' media='all' />
<link rel='stylesheet' id='elementor-icons-fa-brands-css'  href='wp-content/plugins/elementor/assets/lib/font-awesome/css/brands.min9e0b.css?ver=5.15.1' media='all' />
<link rel='stylesheet' id='elementor-icons-fa-solid-css'  href='wp-content/plugins/elementor/assets/lib/font-awesome/css/solid.min9e0b.css?ver=5.15.1' media='all' />
<link rel='stylesheet' id='elementor-icons-fa-regular-css'  href='wp-content/plugins/elementor/assets/lib/font-awesome/css/regular.min9e0b.css?ver=5.15.1' media='all' />
<script src='wp-includes/js/jquery/jquery.min9d52.js?ver=3.5.1' id='jquery-core-js'></script>
<script src='wp-includes/js/jquery/jquery-migrate.mind617.js?ver=3.3.2' id='jquery-migrate-js'></script>
<script src='wp-content/themes/twentytwenty/assets/js/index97e1.js?ver=1.7' id='twentytwenty-js-js' async></script>
<script src='https://www.googletagmanager.com/gtag/js?id=UA-191916219-1' id='google_gtagjs-js' async></script>
<script id='google_gtagjs-js-after'>
window.dataLayer = window.dataLayer || [];function gtag(){dataLayer.push(arguments);}
gtag("js", new Date());
gtag("set", "developer_id.dZTNiMT", true);
gtag("config", "UA-191916219-1", {"anonymize_ip":true});
</script>
<link rel="https://api.w.org/" href="wp-json/index.html" /><link rel="alternate" type="application/json" href="wp-json/wp/v2/pages/132.json" /><link rel="EditURI" type="application/rsd+xml" title="RSD" href="xmlrpc0db0.php?rsd" />
<link rel="wlwmanifest" type="application/wlwmanifest+xml" href="wp-includes/wlwmanifest.xml" /> 
<meta name="generator" content="WordPress 5.7" />
<link rel="canonical" href="index.html" />
<link rel='shortlink' href='index.html' />
<link rel="alternate" type="application/json+oembed" href="wp-json/oembed/1.0/embed3a07.json?url=https%3A%2F%2Fjasafollowersaktif.online%2F" />
<link rel="alternate" type="text/xml+oembed" href="wp-json/oembed/1.0/embed2be4?url=https%3A%2F%2Fjasafollowersaktif.online%2F&amp;format=xml" />
<meta name="generator" content="Site Kit by Google 1.29.0" /><!-- Google Tag Manager -->
<script>(function(w,d,s,l,i){w[l]=w[l]||[];w[l].push({'gtm.start':
new Date().getTime(),event:'gtm.js'});var f=d.getElementsByTagName(s)[0],
j=d.createElement(s),dl=l!='dataLayer'?'&l='+l:'';j.async=true;j.src=
'../www.googletagmanager.com/gtm5445.html?id='+i+dl;f.parentNode.insertBefore(j,f);
})(window,document,'script','dataLayer','GTM-MQ8NC26');</script>
<!-- End Google Tag Manager -->	<script>document.documentElement.className = document.documentElement.className.replace( 'no-js', 'js' );</script>
	<!-- Google Tag Manager added by Site Kit -->
<script>
( function( w, d, s, l, i ) {
	w[l] = w[l] || [];
	w[l].push( {'gtm.start': new Date().getTime(), event: 'gtm.js'} );
	var f = d.getElementsByTagName( s )[0],
		j = d.createElement( s ), dl = l != 'dataLayer' ? '&l=' + l : '';
	j.async = true;
	j.src = '../www.googletagmanager.com/gtm5445.html?id=' + i + dl;
	f.parentNode.insertBefore( j, f );
} )( window, document, 'script', 'dataLayer', 'GTM-MQ8NC26' );
</script>
<!-- End Google Tag Manager -->
			<meta name="viewport" content="width=device-width, initial-scale=1.0, viewport-fit=cover" /></head>
<body class="home page-template page-template-elementor_canvas page page-id-132 wp-embed-responsive singular missing-post-thumbnail has-no-pagination not-showing-comments show-avatars elementor_canvas footer-top-hidden elementor-default elementor-template-canvas elementor-kit-13 elementor-page elementor-page-132">
			<!-- Google Tag Manager (noscript) added by Site Kit -->
		<noscript>
			<iframe src="https://www.googletagmanager.com/ns.html?id=GTM-MQ8NC26" height="0" width="0" style="display:none;visibility:hidden"></iframe>
		</noscript>
		<!-- End Google Tag Manager (noscript) -->
		<!-- Google Tag Manager (noscript) -->
<noscript><iframe src="https://www.googletagmanager.com/ns.html?id=GTM-MQ8NC26"
height="0" width="0" style="display:none;visibility:hidden"></iframe></noscript>
<!-- End Google Tag Manager (noscript) --><a class="skip-link screen-reader-text" href="#site-content">Skip to the content</a>		<div data-elementor-type="wp-page" data-elementor-id="132" class="elementor elementor-132" data-elementor-settings="[]">
							<div class="elementor-section-wrap">
							<section class="elementor-section elementor-top-section elementor-element elementor-element-59281620 elementor-section-boxed elementor-section-height-default elementor-section-height-default" data-id="59281620" data-element_type="section" data-settings="{&quot;background_background&quot;:&quot;classic&quot;}">
						<div class="elementor-container elementor-column-gap-default">
					<div class="elementor-column elementor-col-50 elementor-top-column elementor-element elementor-element-35ce06b2" data-id="35ce06b2" data-element_type="column">
			<div class="elementor-widget-wrap elementor-element-populated">
								<div class="elementor-element elementor-element-3e113666 elementor-widget elementor-widget-image" data-id="3e113666" data-element_type="widget" data-widget_type="image.default">
				<div class="elementor-widget-container">
					<div class="elementor-image">
											<a href="https://jasafollowersaktif.com//home/">
							<img width="323" height="89" src="wp-content/uploads/2021/03/Salinan-dari-Salinan-dari-Salinan-dari-Tanpa-judul3-min-1.png" class="attachment-full size-full" alt="" loading="lazy" srcset="https://jasafollowersaktif.online/wp-content/uploads/2021/03/Salinan-dari-Salinan-dari-Salinan-dari-Tanpa-judul3-min-1.png 323w, https://jasafollowersaktif.online/wp-content/uploads/2021/03/Salinan-dari-Salinan-dari-Salinan-dari-Tanpa-judul3-min-1-300x83.png 300w" sizes="(max-width: 323px) 100vw, 323px" />								</a>
											</div>
				</div>
				</div>
					</div>
		</div>
				<div class="elementor-column elementor-col-50 elementor-top-column elementor-element elementor-element-50e677bf" data-id="50e677bf" data-element_type="column">
			<div class="elementor-widget-wrap">
									</div>
		</div>
							</div>
		</section>
				<section class="elementor-section elementor-top-section elementor-element elementor-element-139a79f3 elementor-section-boxed elementor-section-height-default elementor-section-height-default" data-id="139a79f3" data-element_type="section">
						<div class="elementor-container elementor-column-gap-default">
					<div class="elementor-column elementor-col-50 elementor-top-column elementor-element elementor-element-7a07b0f2" data-id="7a07b0f2" data-element_type="column">
			<div class="elementor-widget-wrap elementor-element-populated">
								<div class="elementor-element elementor-element-4133579f elementor-widget elementor-widget-heading" data-id="4133579f" data-element_type="widget" data-widget_type="heading.default">
				<div class="elementor-widget-container">
			<h2 class="elementor-heading-title elementor-size-default">Jual Followers Instagram Aktif Indonesia.</h2>		</div>
				</div>
				<div class="elementor-element elementor-element-2fcd6768 elementor-widget elementor-widget-text-editor" data-id="2fcd6768" data-element_type="widget" data-widget_type="text-editor.default">
				<div class="elementor-widget-container">
					<div class="elementor-text-editor elementor-clearfix"><p>Kami adalah platform yang aman, murah dan terpercaya yang menyediakan kebutuhan-kebutuhan sosial media untuk bisnis anda dengan jaminan garansi 100%.</p></div>
				</div>
				</div>
				<div class="elementor-element elementor-element-1d979065 elementor-button-success elementor-align-center elementor-widget elementor-widget-button" data-id="1d979065" data-element_type="widget" data-widget_type="button.default">
				<div class="elementor-widget-container">
					<div class="elementor-button-wrapper">
			<a href="cs.php" target="_blank" class="elementor-button-link elementor-button elementor-size-sm" role="button">
						<span class="elementor-button-content-wrapper">
						<span class="elementor-button-icon elementor-align-icon-left">
				<i aria-hidden="true" class="fab fa-whatsapp"></i>			</span>
						<span class="elementor-button-text">ORDER SEKARANG</span>
		</span>
					</a>
		</div>
				</div>
				</div>
					</div>
		</div>
				<div class="elementor-column elementor-col-50 elementor-top-column elementor-element elementor-element-3c58d697" data-id="3c58d697" data-element_type="column">
			<div class="elementor-widget-wrap elementor-element-populated">
								<div class="elementor-element elementor-element-53d8747b elementor-widget elementor-widget-image" data-id="53d8747b" data-element_type="widget" data-widget_type="image.default">
				<div class="elementor-widget-container">
					<div class="elementor-image">
										<img width="1350" height="900" src="wp-content/uploads/2021/03/Salinan-dari-Salinan-dari-Salinan-dari-Tanpa-judul6-min-1.png" class="attachment-full size-full" alt="" loading="lazy" srcset="https://jasafollowersaktif.online/wp-content/uploads/2021/03/Salinan-dari-Salinan-dari-Salinan-dari-Tanpa-judul6-min-1.png 1350w, https://jasafollowersaktif.online/wp-content/uploads/2021/03/Salinan-dari-Salinan-dari-Salinan-dari-Tanpa-judul6-min-1-300x200.png 300w, https://jasafollowersaktif.online/wp-content/uploads/2021/03/Salinan-dari-Salinan-dari-Salinan-dari-Tanpa-judul6-min-1-1024x683.png 1024w, https://jasafollowersaktif.online/wp-content/uploads/2021/03/Salinan-dari-Salinan-dari-Salinan-dari-Tanpa-judul6-min-1-768x512.png 768w, https://jasafollowersaktif.online/wp-content/uploads/2021/03/Salinan-dari-Salinan-dari-Salinan-dari-Tanpa-judul6-min-1-1200x800.png 1200w" sizes="(max-width: 1350px) 100vw, 1350px" />											</div>
				</div>
				</div>
					</div>
		</div>
							</div>
		</section>
				<section class="elementor-section elementor-top-section elementor-element elementor-element-8606029 elementor-section-boxed elementor-section-height-default elementor-section-height-default" data-id="8606029" data-element_type="section" data-settings="{&quot;background_background&quot;:&quot;classic&quot;}">
						<div class="elementor-container elementor-column-gap-default">
					<div class="elementor-column elementor-col-25 elementor-top-column elementor-element elementor-element-5e819b7f" data-id="5e819b7f" data-element_type="column">
			<div class="elementor-widget-wrap elementor-element-populated">
								<div class="elementor-element elementor-element-7ebcd0ca elementor-view-default elementor-widget elementor-widget-icon" data-id="7ebcd0ca" data-element_type="widget" data-widget_type="icon.default">
				<div class="elementor-widget-container">
					<div class="elementor-icon-wrapper">
			<div class="elementor-icon">
			<i aria-hidden="true" class="fas fa-check-circle"></i>			</div>
		</div>
				</div>
				</div>
				<div class="elementor-element elementor-element-4610dd3d elementor-widget elementor-widget-counter" data-id="4610dd3d" data-element_type="widget" data-widget_type="counter.default">
				<div class="elementor-widget-container">
					<div class="elementor-counter">
			<div class="elementor-counter-number-wrapper">
				<span class="elementor-counter-number-prefix"></span>
				<span class="elementor-counter-number" data-duration="2000" data-to-value="11365" data-from-value="0" data-delimiter=",">0</span>
				<span class="elementor-counter-number-suffix"></span>
			</div>
							<div class="elementor-counter-title">Pesanan Selesai</div>
					</div>
				</div>
				</div>
					</div>
		</div>
				<div class="elementor-column elementor-col-25 elementor-top-column elementor-element elementor-element-62d123ea" data-id="62d123ea" data-element_type="column">
			<div class="elementor-widget-wrap elementor-element-populated">
								<div class="elementor-element elementor-element-e217f3e elementor-view-default elementor-widget elementor-widget-icon" data-id="e217f3e" data-element_type="widget" data-widget_type="icon.default">
				<div class="elementor-widget-container">
					<div class="elementor-icon-wrapper">
			<div class="elementor-icon">
			<i aria-hidden="true" class="far fa-hourglass"></i>			</div>
		</div>
				</div>
				</div>
				<div class="elementor-element elementor-element-10df84f6 elementor-widget elementor-widget-counter" data-id="10df84f6" data-element_type="widget" data-widget_type="counter.default">
				<div class="elementor-widget-container">
					<div class="elementor-counter">
			<div class="elementor-counter-number-wrapper">
				<span class="elementor-counter-number-prefix"></span>
				<span class="elementor-counter-number" data-duration="2000" data-to-value="5664" data-from-value="0" data-delimiter=",">0</span>
				<span class="elementor-counter-number-suffix"></span>
			</div>
							<div class="elementor-counter-title">Pesanan di Proses</div>
					</div>
				</div>
				</div>
					</div>
		</div>
				<div class="elementor-column elementor-col-25 elementor-top-column elementor-element elementor-element-12141692" data-id="12141692" data-element_type="column">
			<div class="elementor-widget-wrap elementor-element-populated">
								<div class="elementor-element elementor-element-2754ba47 elementor-view-default elementor-widget elementor-widget-icon" data-id="2754ba47" data-element_type="widget" data-widget_type="icon.default">
				<div class="elementor-widget-container">
					<div class="elementor-icon-wrapper">
			<div class="elementor-icon">
			<i aria-hidden="true" class="far fa-money-bill-alt"></i>			</div>
		</div>
				</div>
				</div>
				<div class="elementor-element elementor-element-333f0e49 elementor-widget elementor-widget-counter" data-id="333f0e49" data-element_type="widget" data-widget_type="counter.default">
				<div class="elementor-widget-container">
					<div class="elementor-counter">
			<div class="elementor-counter-number-wrapper">
				<span class="elementor-counter-number-prefix"></span>
				<span class="elementor-counter-number" data-duration="2000" data-to-value="4985" data-from-value="0" data-delimiter=",">0</span>
				<span class="elementor-counter-number-suffix"></span>
			</div>
							<div class="elementor-counter-title">Sudah Membayar</div>
					</div>
				</div>
				</div>
					</div>
		</div>
				<div class="elementor-column elementor-col-25 elementor-top-column elementor-element elementor-element-97aa3ac" data-id="97aa3ac" data-element_type="column">
			<div class="elementor-widget-wrap elementor-element-populated">
								<div class="elementor-element elementor-element-711e11a8 elementor-view-default elementor-widget elementor-widget-icon" data-id="711e11a8" data-element_type="widget" data-widget_type="icon.default">
				<div class="elementor-widget-container">
					<div class="elementor-icon-wrapper">
			<div class="elementor-icon">
			<i aria-hidden="true" class="far fa-eye"></i>			</div>
		</div>
				</div>
				</div>
				<div class="elementor-element elementor-element-706d121d elementor-widget elementor-widget-counter" data-id="706d121d" data-element_type="widget" data-widget_type="counter.default">
				<div class="elementor-widget-container">
					<div class="elementor-counter">
			<div class="elementor-counter-number-wrapper">
				<span class="elementor-counter-number-prefix"></span>
				<span class="elementor-counter-number" data-duration="2000" data-to-value="39522" data-from-value="0" data-delimiter=",">0</span>
				<span class="elementor-counter-number-suffix"></span>
			</div>
							<div class="elementor-counter-title">Total Pengunjung</div>
					</div>
				</div>
				</div>
					</div>
		</div>
							</div>
		</section>
				<section class="elementor-section elementor-top-section elementor-element elementor-element-63548b22 elementor-section-boxed elementor-section-height-default elementor-section-height-default" data-id="63548b22" data-element_type="section">
						<div class="elementor-container elementor-column-gap-default">
					<div class="elementor-column elementor-col-100 elementor-top-column elementor-element elementor-element-104cb9b8" data-id="104cb9b8" data-element_type="column">
			<div class="elementor-widget-wrap elementor-element-populated">
								<div class="elementor-element elementor-element-c9c1cb0 elementor-widget elementor-widget-heading" data-id="c9c1cb0" data-element_type="widget" data-widget_type="heading.default">
				<div class="elementor-widget-container">
			<h5 class="elementor-heading-title elementor-size-large">Mereka Yang Sudah Menggunakan Jasa Followers Kami</h5>		</div>
				</div>
					</div>
		</div>
							</div>
		</section>
				<section class="elementor-section elementor-top-section elementor-element elementor-element-60f669f3 elementor-section-boxed elementor-section-height-default elementor-section-height-default" data-id="60f669f3" data-element_type="section">
						<div class="elementor-container elementor-column-gap-default">
					<div class="elementor-column elementor-col-100 elementor-top-column elementor-element elementor-element-417c5758" data-id="417c5758" data-element_type="column">
			<div class="elementor-widget-wrap elementor-element-populated">
								<div class="elementor-element elementor-element-6e8b7b70 elementor-skin-carousel elementor-arrows-yes elementor-pagination-type-bullets elementor-pagination-position-outside elementor-widget elementor-widget-media-carousel" data-id="6e8b7b70" data-element_type="widget" data-settings="{&quot;slides_per_view&quot;:&quot;3&quot;,&quot;speed&quot;:300,&quot;autoplay_speed&quot;:3000,&quot;skin&quot;:&quot;carousel&quot;,&quot;effect&quot;:&quot;slide&quot;,&quot;show_arrows&quot;:&quot;yes&quot;,&quot;pagination&quot;:&quot;bullets&quot;,&quot;autoplay&quot;:&quot;yes&quot;,&quot;loop&quot;:&quot;yes&quot;,&quot;pause_on_hover&quot;:&quot;yes&quot;,&quot;pause_on_interaction&quot;:&quot;yes&quot;,&quot;space_between&quot;:{&quot;unit&quot;:&quot;px&quot;,&quot;size&quot;:10,&quot;sizes&quot;:[]},&quot;space_between_tablet&quot;:{&quot;unit&quot;:&quot;px&quot;,&quot;size&quot;:10,&quot;sizes&quot;:[]},&quot;space_between_mobile&quot;:{&quot;unit&quot;:&quot;px&quot;,&quot;size&quot;:10,&quot;sizes&quot;:[]}}" data-widget_type="media-carousel.default">
				<div class="elementor-widget-container">
					<div class="elementor-swiper">
			<div class="elementor-main-swiper swiper-container">
				<div class="swiper-wrapper">
											<div class="swiper-slide">
									<div class="elementor-carousel-image" style="background-image: url(wp-content/uploads/2021/03/Jasa-Followers-Aktif-Mantab-min-1.png)">
					</div>
								</div>
											<div class="swiper-slide">
									<div class="elementor-carousel-image" style="background-image: url(wp-content/uploads/2021/03/Jasa-Followers-Aktif-Bagus-min-1.png)">
					</div>
								</div>
											<div class="swiper-slide">
									<div class="elementor-carousel-image" style="background-image: url(wp-content/uploads/2021/03/Jasa-Followers-Aktif-03-min-1.png)">
					</div>
								</div>
											<div class="swiper-slide">
									<div class="elementor-carousel-image" style="background-image: url(wp-content/uploads/2021/03/Jasa-Followers-Aktif-01-min-1.png)">
					</div>
								</div>
									</div>
															<div class="swiper-pagination"></div>
																<div class="elementor-swiper-button elementor-swiper-button-prev">
							<i class="eicon-chevron-left" aria-hidden="true"></i>
							<span class="elementor-screen-only">Previous</span>
						</div>
						<div class="elementor-swiper-button elementor-swiper-button-next">
							<i class="eicon-chevron-right" aria-hidden="true"></i>
							<span class="elementor-screen-only">Next</span>
						</div>
												</div>
		</div>
				</div>
				</div>
				<div class="elementor-element elementor-element-1d3af6af elementor-blockquote--skin-border elementor-blockquote--button-color-official elementor-widget elementor-widget-blockquote" data-id="1d3af6af" data-element_type="widget" data-widget_type="blockquote.default">
				<div class="elementor-widget-container">
					<blockquote class="elementor-blockquote">
			<p class="elementor-blockquote__content">
				Testimoni Diatas Hanya Sebagian Dari Ribuan Testimoni Yang Ada, Insya Allah Bermanfaat Untuk Kebutuhan Sosmed Kita, Aamiin			</p>
					</blockquote>
				</div>
				</div>
					</div>
		</div>
							</div>
		</section>
				<section class="elementor-section elementor-top-section elementor-element elementor-element-41a7815 elementor-section-boxed elementor-section-height-default elementor-section-height-default" data-id="41a7815" data-element_type="section">
						<div class="elementor-container elementor-column-gap-default">
					<div class="elementor-column elementor-col-100 elementor-top-column elementor-element elementor-element-187985d4" data-id="187985d4" data-element_type="column">
			<div class="elementor-widget-wrap elementor-element-populated">
								<div class="elementor-element elementor-element-5c80f44e elementor-button-success elementor-align-center elementor-widget elementor-widget-button" data-id="5c80f44e" data-element_type="widget" data-widget_type="button.default">
				<div class="elementor-widget-container">
					<div class="elementor-button-wrapper">
			<a href="cs.php" target="_blank" class="elementor-button-link elementor-button elementor-size-sm" role="button">
						<span class="elementor-button-content-wrapper">
						<span class="elementor-button-icon elementor-align-icon-left">
				<i aria-hidden="true" class="fab fa-whatsapp"></i>			</span>
						<span class="elementor-button-text">ORDER SEKARANG</span>
		</span>
					</a>
		</div>
				</div>
				</div>
					</div>
		</div>
							</div>
		</section>
				<section class="elementor-section elementor-top-section elementor-element elementor-element-864c9ad elementor-section-boxed elementor-section-height-default elementor-section-height-default" data-id="864c9ad" data-element_type="section">
						<div class="elementor-container elementor-column-gap-default">
					<div class="elementor-column elementor-col-100 elementor-top-column elementor-element elementor-element-296daefc" data-id="296daefc" data-element_type="column">
			<div class="elementor-widget-wrap elementor-element-populated">
								<div class="elementor-element elementor-element-4c26bbde elementor-widget elementor-widget-heading" data-id="4c26bbde" data-element_type="widget" data-widget_type="heading.default">
				<div class="elementor-widget-container">
			<h5 class="elementor-heading-title elementor-size-large">Kenapa Harus Jasa Followes Kami</h5>		</div>
				</div>
					</div>
		</div>
							</div>
		</section>
				<section class="elementor-section elementor-top-section elementor-element elementor-element-9424140 elementor-section-boxed elementor-section-height-default elementor-section-height-default" data-id="9424140" data-element_type="section">
						<div class="elementor-container elementor-column-gap-default">
					<div class="elementor-column elementor-col-25 elementor-top-column elementor-element elementor-element-3010f263" data-id="3010f263" data-element_type="column">
			<div class="elementor-widget-wrap elementor-element-populated">
								<div class="elementor-element elementor-element-211997b5 elementor-view-default elementor-widget elementor-widget-icon" data-id="211997b5" data-element_type="widget" data-widget_type="icon.default">
				<div class="elementor-widget-container">
					<div class="elementor-icon-wrapper">
			<div class="elementor-icon">
			<i aria-hidden="true" class="fas fa-stopwatch"></i>			</div>
		</div>
				</div>
				</div>
				<div class="elementor-element elementor-element-4a90b27f elementor-widget elementor-widget-text-editor" data-id="4a90b27f" data-element_type="widget" data-widget_type="text-editor.default">
				<div class="elementor-widget-container">
					<div class="elementor-text-editor elementor-clearfix"><p>Proses sangat cepat dan instant, di bandingkan harus melakukan marketing bulanan sendiri.</p></div>
				</div>
				</div>
					</div>
		</div>
				<div class="elementor-column elementor-col-25 elementor-top-column elementor-element elementor-element-6e8c7a37" data-id="6e8c7a37" data-element_type="column">
			<div class="elementor-widget-wrap elementor-element-populated">
								<div class="elementor-element elementor-element-27297ae6 elementor-view-default elementor-widget elementor-widget-icon" data-id="27297ae6" data-element_type="widget" data-widget_type="icon.default">
				<div class="elementor-widget-container">
					<div class="elementor-icon-wrapper">
			<div class="elementor-icon">
			<i aria-hidden="true" class="far fa-clock"></i>			</div>
		</div>
				</div>
				</div>
				<div class="elementor-element elementor-element-39f69f2a elementor-widget elementor-widget-text-editor" data-id="39f69f2a" data-element_type="widget" data-widget_type="text-editor.default">
				<div class="elementor-widget-container">
					<div class="elementor-text-editor elementor-clearfix"><p>Dengan system support 24 jam, sehingga memudahkan anda untuk dapat berkonsultasi.</p></div>
				</div>
				</div>
					</div>
		</div>
				<div class="elementor-column elementor-col-25 elementor-top-column elementor-element elementor-element-70dbe948" data-id="70dbe948" data-element_type="column">
			<div class="elementor-widget-wrap elementor-element-populated">
								<div class="elementor-element elementor-element-53a88cfb elementor-view-default elementor-widget elementor-widget-icon" data-id="53a88cfb" data-element_type="widget" data-widget_type="icon.default">
				<div class="elementor-widget-container">
					<div class="elementor-icon-wrapper">
			<div class="elementor-icon">
			<i aria-hidden="true" class="fab fa-whatsapp"></i>			</div>
		</div>
				</div>
				</div>
				<div class="elementor-element elementor-element-3d74d383 elementor-widget elementor-widget-text-editor" data-id="3d74d383" data-element_type="widget" data-widget_type="text-editor.default">
				<div class="elementor-widget-container">
					<div class="elementor-text-editor elementor-clearfix"><p>Transaksi lebih mudah, praktis, dan aman karena seluruh transaksi langsung melalui Whatsapp.</p></div>
				</div>
				</div>
					</div>
		</div>
				<div class="elementor-column elementor-col-25 elementor-top-column elementor-element elementor-element-4cdec723" data-id="4cdec723" data-element_type="column">
			<div class="elementor-widget-wrap elementor-element-populated">
								<div class="elementor-element elementor-element-3f0dc5f0 elementor-view-default elementor-widget elementor-widget-icon" data-id="3f0dc5f0" data-element_type="widget" data-widget_type="icon.default">
				<div class="elementor-widget-container">
					<div class="elementor-icon-wrapper">
			<div class="elementor-icon">
			<i aria-hidden="true" class="fas fa-key"></i>			</div>
		</div>
				</div>
				</div>
				<div class="elementor-element elementor-element-1a90a93b elementor-widget elementor-widget-text-editor" data-id="1a90a93b" data-element_type="widget" data-widget_type="text-editor.default">
				<div class="elementor-widget-container">
					<div class="elementor-text-editor elementor-clearfix"><p>Proses hanya memerlukan username tanpa memerlukan password, sehingga akun anda kami jamin dan kami garansi 100% .</p></div>
				</div>
				</div>
					</div>
		</div>
							</div>
		</section>
				<section class="elementor-section elementor-top-section elementor-element elementor-element-a65920c elementor-section-boxed elementor-section-height-default elementor-section-height-default" data-id="a65920c" data-element_type="section">
						<div class="elementor-container elementor-column-gap-default">
					<div class="elementor-column elementor-col-100 elementor-top-column elementor-element elementor-element-7d6099e7" data-id="7d6099e7" data-element_type="column">
			<div class="elementor-widget-wrap elementor-element-populated">
								<div class="elementor-element elementor-element-6c40574e elementor-widget elementor-widget-heading" data-id="6c40574e" data-element_type="widget" data-widget_type="heading.default">
				<div class="elementor-widget-container">
			<h5 class="elementor-heading-title elementor-size-large">Harga Dan Cara Order</h5>		</div>
				</div>
					</div>
		</div>
							</div>
		</section>
				<section class="elementor-section elementor-top-section elementor-element elementor-element-3e89d58c elementor-section-boxed elementor-section-height-default elementor-section-height-default" data-id="3e89d58c" data-element_type="section">
						<div class="elementor-container elementor-column-gap-default">
					<div class="elementor-column elementor-col-100 elementor-top-column elementor-element elementor-element-44a90281" data-id="44a90281" data-element_type="column">
			<div class="elementor-widget-wrap elementor-element-populated">
								<div class="elementor-element elementor-element-2b97e957 elementor-skin-carousel elementor-arrows-yes elementor-pagination-type-bullets elementor-pagination-position-outside elementor-widget elementor-widget-media-carousel" data-id="2b97e957" data-element_type="widget" data-settings="{&quot;skin&quot;:&quot;carousel&quot;,&quot;effect&quot;:&quot;slide&quot;,&quot;show_arrows&quot;:&quot;yes&quot;,&quot;pagination&quot;:&quot;bullets&quot;,&quot;speed&quot;:500,&quot;autoplay&quot;:&quot;yes&quot;,&quot;autoplay_speed&quot;:5000,&quot;loop&quot;:&quot;yes&quot;,&quot;pause_on_hover&quot;:&quot;yes&quot;,&quot;pause_on_interaction&quot;:&quot;yes&quot;,&quot;space_between&quot;:{&quot;unit&quot;:&quot;px&quot;,&quot;size&quot;:10,&quot;sizes&quot;:[]},&quot;space_between_tablet&quot;:{&quot;unit&quot;:&quot;px&quot;,&quot;size&quot;:10,&quot;sizes&quot;:[]},&quot;space_between_mobile&quot;:{&quot;unit&quot;:&quot;px&quot;,&quot;size&quot;:10,&quot;sizes&quot;:[]}}" data-widget_type="media-carousel.default">
				<div class="elementor-widget-container">
					<div class="elementor-swiper">
			<div class="elementor-main-swiper swiper-container">
				<div class="swiper-wrapper">
											<div class="swiper-slide">
									<div class="elementor-carousel-image" style="background-image: url(wp-content/uploads/2021/03/harga.jpg)">
					</div>
								</div>
											<div class="swiper-slide">
									<div class="elementor-carousel-image" style="background-image: url(wp-content/uploads/2021/03/cara-order.jpg)">
					</div>
								</div>
											<div class="swiper-slide">
									<div class="elementor-carousel-image" style="background-image: url(wp-content/uploads/2021/03/kenapa.jpg)">
					</div>
								</div>
											<div class="swiper-slide">
									<div class="elementor-carousel-image" style="background-image: url(wp-content/uploads/2021/03/Discount-50-min.jpg)">
					</div>
								</div>
									</div>
															<div class="swiper-pagination"></div>
																<div class="elementor-swiper-button elementor-swiper-button-prev">
							<i class="eicon-chevron-left" aria-hidden="true"></i>
							<span class="elementor-screen-only">Previous</span>
						</div>
						<div class="elementor-swiper-button elementor-swiper-button-next">
							<i class="eicon-chevron-right" aria-hidden="true"></i>
							<span class="elementor-screen-only">Next</span>
						</div>
												</div>
		</div>
				</div>
				</div>
					</div>
		</div>
							</div>
		</section>
				<section class="elementor-section elementor-top-section elementor-element elementor-element-769e3bb2 elementor-section-boxed elementor-section-height-default elementor-section-height-default" data-id="769e3bb2" data-element_type="section">
						<div class="elementor-container elementor-column-gap-default">
					<div class="elementor-column elementor-col-100 elementor-top-column elementor-element elementor-element-10d8197b" data-id="10d8197b" data-element_type="column">
			<div class="elementor-widget-wrap elementor-element-populated">
								<div class="elementor-element elementor-element-73b542ac elementor-button-success elementor-align-center elementor-widget elementor-widget-button" data-id="73b542ac" data-element_type="widget" data-widget_type="button.default">
				<div class="elementor-widget-container">
					<div class="elementor-button-wrapper">
			<a href="cs.php" target="_blank" class="elementor-button-link elementor-button elementor-size-sm" role="button">
						<span class="elementor-button-content-wrapper">
						<span class="elementor-button-icon elementor-align-icon-left">
				<i aria-hidden="true" class="fab fa-whatsapp"></i>			</span>
						<span class="elementor-button-text">ORDER SEKARANG</span>
		</span>
					</a>
		</div>
				</div>
				</div>
				<div class="elementor-element elementor-element-5413472a elementor-headline--style-highlight elementor-widget elementor-widget-animated-headline" data-id="5413472a" data-element_type="widget" data-settings="{&quot;highlighted_text&quot;:&quot;Berakhir &quot;,&quot;highlight_iteration_delay&quot;:2000,&quot;headline_style&quot;:&quot;highlight&quot;,&quot;marker&quot;:&quot;circle&quot;,&quot;loop&quot;:&quot;yes&quot;,&quot;highlight_animation_duration&quot;:1200}" data-widget_type="animated-headline.default">
				<div class="elementor-widget-container">
					<p class="elementor-headline">
					<span class="elementor-headline-plain-text elementor-headline-text-wrapper">Promo Hari Ini Akan Segera</span>
				<span class="elementor-headline-dynamic-wrapper elementor-headline-text-wrapper">
					<span class="elementor-headline-dynamic-text elementor-headline-text-active">Berakhir </span>
				</span>
					<span class="elementor-headline-plain-text elementor-headline-text-wrapper">Dalam Beberapa Waktu Lagi</span>
					</p>
				</div>
				</div>
				<div class="elementor-element elementor-element-554ea0d8 elementor-countdown--label-block elementor-widget elementor-widget-countdown" data-id="554ea0d8" data-element_type="widget" data-widget_type="countdown.default">
				<div class="elementor-widget-container">
					<div data-evergreen-interval="22200" class="elementor-countdown-wrapper" data-date="">
			<div class="elementor-countdown-item"><span class="elementor-countdown-digits elementor-countdown-hours"></span> <span class="elementor-countdown-label">Jam</span></div><div class="elementor-countdown-item"><span class="elementor-countdown-digits elementor-countdown-minutes"></span> <span class="elementor-countdown-label">Menit</span></div><div class="elementor-countdown-item"><span class="elementor-countdown-digits elementor-countdown-seconds"></span> <span class="elementor-countdown-label">Detik</span></div>		</div>
				</div>
				</div>
				<div class="elementor-element elementor-element-55b6f91f elementor-widget elementor-widget-text-editor" data-id="55b6f91f" data-element_type="widget" data-widget_type="text-editor.default">
				<div class="elementor-widget-container">
					<div class="elementor-text-editor elementor-clearfix"><p>* Jika promo habis, promo akan dimulai lagi besok atau Whatsapp kami untuk penawaran spesial</p></div>
				</div>
				</div>
				<div class="elementor-element elementor-element-5b791e8d elementor-button-success elementor-align-center elementor-widget elementor-widget-button" data-id="5b791e8d" data-element_type="widget" data-widget_type="button.default">
				<div class="elementor-widget-container">
					<div class="elementor-button-wrapper">
			<a href="cs.php" target="_blank" class="elementor-button-link elementor-button elementor-size-sm" role="button">
						<span class="elementor-button-content-wrapper">
						<span class="elementor-button-icon elementor-align-icon-left">
				<i aria-hidden="true" class="fab fa-whatsapp"></i>			</span>
						<span class="elementor-button-text">ORDER SEKARANG</span>
		</span>
					</a>
		</div>
				</div>
				</div>
				<div class="elementor-element elementor-element-21887cc6 elementor-widget elementor-widget-heading" data-id="21887cc6" data-element_type="widget" data-widget_type="heading.default">
				<div class="elementor-widget-container">
			<h5 class="elementor-heading-title elementor-size-default">100% Garansi Saya Berikan Untuk Anda,
Garansi Uang Kembali 100% Jika Followers Tidak Masuk Atau Tidak Maksimal .</h5>		</div>
				</div>
					</div>
		</div>
							</div>
		</section>
						</div>
					</div>
		<script id='ht_ctc_app_js-js-extra'>
var ht_ctc_chat_var = {"number":"6281511931581","pre_filled":"Hi Kak, mau tanya-tanya jasa tambah followers & like instagramnya aktif boleh?","dis_m":"show","dis_d":"show","css":"display: none; cursor: pointer; z-index: 99999999;","pos_d":"position: fixed; bottom: 30px; right: 30px;","pos_m":"position: fixed; bottom: 30px; right: 30px;","webandapi":"wa","schedule":"no","ga":"yes","fb":"yes","ads":"no","se":"120","ani":"no-animations","v":"3.2.9"};
</script>
<script src='wp-content/plugins/click-to-chat-for-whatsapp/new/inc/assets/js/appc092.js?ver=3.2.9' id='ht_ctc_app_js-js'></script>
<script src='wp-includes/js/wp-embed.mine23c.js?ver=5.7' id='wp-embed-js'></script>
<script src='wp-content/plugins/elementor/assets/lib/jquery-numerator/jquery-numerator.min3958.js?ver=0.2.1' id='jquery-numerator-js'></script>
<script src='wp-includes/js/imagesloaded.mineda1.js?ver=4.1.4' id='imagesloaded-js'></script>
<script src='wp-content/plugins/elementor-pro/assets/js/webpack-pro.runtime.minb12b.js?ver=3.1.1' id='elementor-pro-webpack-runtime-js'></script>
<script src='wp-content/plugins/elementor/assets/js/webpack.runtime.minaeb9.js?ver=3.1.4' id='elementor-webpack-runtime-js'></script>
<script src='wp-content/plugins/elementor/assets/js/frontend-modules.minaeb9.js?ver=3.1.4' id='elementor-frontend-modules-js'></script>
<script src='wp-content/plugins/elementor-pro/assets/lib/sticky/jquery.sticky.minb12b.js?ver=3.1.1' id='elementor-sticky-js'></script>
<script id='elementor-pro-frontend-js-before'>
var ElementorProFrontendConfig = {"ajaxurl":"https:\/\/jasafollowersaktif.online\/wp-admin\/admin-ajax.php","nonce":"5a1ae03b9f","urls":{"assets":"https:\/\/jasafollowersaktif.online\/wp-content\/plugins\/elementor-pro\/assets\/"},"i18n":{"toc_no_headings_found":"No headings were found on this page."},"shareButtonsNetworks":{"facebook":{"title":"Facebook","has_counter":true},"twitter":{"title":"Twitter"},"google":{"title":"Google+","has_counter":true},"linkedin":{"title":"LinkedIn","has_counter":true},"pinterest":{"title":"Pinterest","has_counter":true},"reddit":{"title":"Reddit","has_counter":true},"vk":{"title":"VK","has_counter":true},"odnoklassniki":{"title":"OK","has_counter":true},"tumblr":{"title":"Tumblr"},"digg":{"title":"Digg"},"skype":{"title":"Skype"},"stumbleupon":{"title":"StumbleUpon","has_counter":true},"mix":{"title":"Mix"},"telegram":{"title":"Telegram"},"pocket":{"title":"Pocket","has_counter":true},"xing":{"title":"XING","has_counter":true},"whatsapp":{"title":"WhatsApp"},"email":{"title":"Email"},"print":{"title":"Print"}},"facebook_sdk":{"lang":"en_US","app_id":""},"lottie":{"defaultAnimationUrl":"https:\/\/jasafollowersaktif.online\/wp-content\/plugins\/elementor-pro\/modules\/lottie\/assets\/animations\/default.json"}};
</script>
<script src='wp-content/plugins/elementor-pro/assets/js/frontend.minb12b.js?ver=3.1.1' id='elementor-pro-frontend-js'></script>
<script src='wp-includes/js/jquery/ui/core.min35d0.js?ver=1.12.1' id='jquery-ui-core-js'></script>
<script src='wp-content/plugins/elementor/assets/lib/dialog/dialog.mina288.js?ver=4.8.1' id='elementor-dialog-js'></script>
<script src='wp-content/plugins/elementor/assets/lib/waypoints/waypoints.min05da.js?ver=4.0.2' id='elementor-waypoints-js'></script>
<script src='wp-content/plugins/elementor/assets/lib/share-link/share-link.minaeb9.js?ver=3.1.4' id='share-link-js'></script>
<script src='wp-content/plugins/elementor/assets/lib/swiper/swiper.min48f5.js?ver=5.3.6' id='swiper-js'></script>
<script id='elementor-frontend-js-before'>
var elementorFrontendConfig = {"environmentMode":{"edit":false,"wpPreview":false,"isScriptDebug":false,"isImprovedAssetsLoading":false},"i18n":{"shareOnFacebook":"Share on Facebook","shareOnTwitter":"Share on Twitter","pinIt":"Pin it","download":"Download","downloadImage":"Download image","fullscreen":"Fullscreen","zoom":"Zoom","share":"Share","playVideo":"Play Video","previous":"Previous","next":"Next","close":"Close"},"is_rtl":false,"breakpoints":{"xs":0,"sm":480,"md":768,"lg":1025,"xl":1440,"xxl":1600},"version":"3.1.4","is_static":false,"experimentalFeatures":{"e_dom_optimization":true,"a11y_improvements":true,"landing-pages":true},"urls":{"assets":"https:\/\/jasafollowersaktif.online\/wp-content\/plugins\/elementor\/assets\/"},"settings":{"page":[],"editorPreferences":[]},"kit":{"global_image_lightbox":"yes","lightbox_enable_counter":"yes","lightbox_enable_fullscreen":"yes","lightbox_enable_zoom":"yes","lightbox_enable_share":"yes","lightbox_title_src":"title","lightbox_description_src":"description"},"post":{"id":132,"title":"","excerpt":"","featuredImage":false}};
</script>
<script src='wp-content/plugins/elementor/assets/js/frontend.minaeb9.js?ver=3.1.4' id='elementor-frontend-js'></script>
<script src='wp-content/plugins/elementor-pro/assets/js/preloaded-elements-handlers.minb12b.js?ver=3.1.1' id='pro-preloaded-elements-handlers-js'></script>
<script src='wp-content/plugins/elementor/assets/js/preloaded-elements-handlers.minaeb9.js?ver=3.1.4' id='preloaded-elements-handlers-js'></script>
	<script>
	/(trident|msie)/i.test(navigator.userAgent)&&document.getElementById&&window.addEventListener&&window.addEventListener("hashchange",function(){var t,e=location.hash.substring(1);/^[A-z0-9_-]+$/.test(e)&&(t=document.getElementById(e))&&(/^(?:a|select|input|button|textarea)$/i.test(t.tagName)||(t.tabIndex=-1),t.focus())},!1);
	</script>
		</body>

<!-- Mirrored from jasafollowersaktif.online/ by HTTrack Website Copier/3.x [XR&CO'2014], Mon, 05 Apr 2021 07:23:44 GMT -->
</html>
